import React from 'react'
import Routers from './routes';

export const App = () => (
  <>
  <Routers/>
  </>
);
