
import React from 'react';
import Spin from 'antd/lib/spin';

// import './style.less';
const FullLoader = () => {
    return (
         <div>
              <Spin size="large" />
         </div>
      );
}
 
export default FullLoader;